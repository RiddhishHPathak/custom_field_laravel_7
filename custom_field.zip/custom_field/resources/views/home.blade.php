
<html>
<head>
    <meta name="csrf-token" content="{{ csrf_token() }}">
<title>Home</title>
<link rel="stylesheet" href="{{asset('assets/bootstrap/dist/css/bootstrap.min.css')}}">
<script src="{{asset('assets/jquery-3.5.1.min.js')}}" type="text/javascript"></script>
<script src="{{asset('assets/bootstrap/dist/js/bootstrap.min.js')}}" type="text/javascript"></script>
</head>
<body>
<br>
<div class="container">
    
<div class="card">
  <div class="card-body">
    <h4 class="card-title">Add Rows and Column </h4>
    <form action="{{route('custom.store')}}" method="post">
    @csrf
    <div class="form-group">
        <label for="row">Rows:</label>
        <input type="text" class="form-control" name="Row" placeholder="Enter Rows" id="Row"><br>
        @error('Row')
            <div class="alert alert-danger">{{ $message }}</div>
        @enderror
    </div>
    <div class="form-group">
        <label for="pwd">Column:</label>
        <input type="text" class="form-control" name="Column" placeholder="Enter Columns" id="Column"><br>
        @error('Column')
            <div class="alert alert-danger">{{ $message }}</div>
        @enderror
    </div>    
    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>
</div>
<br>
<div id="result"></div>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
        <form method="POST" id="ProductUpdate">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Data Form:</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
        @method('patch')
      <div class="modal-body">
        <div class="form-group">
            <label for="ItemName">Item Name:</label>
            <input type="text" class="form-control" name="ItemName" placeholder="Enter Item Name" required id="ItemName">
        </div>
        <div class="form-group">
            <label for="Price">Price:</label>
            <input type="text" class="form-control" onkeypress="return isNumberKey(event,this)" name="Price" placeholder="Enter Price" required id="Price">
        </div>
      </div>
      <div class="modal-footer">
        <input type="hidden" name="Row" id="Row1" value="">
        <input type="hidden" name="Column" id="Column1" value="">        
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
  </form>
    </div>
  </div>
</div>

</div>
<script type="text/javascript">
    if({{$check['id']}}==1){
       getData(); 
    }
    
    function getData(){
        $.ajax({
            type:'get',
            url:"{{route('custom.showAll')}}",
            success:function($data){                
                $('#result').html($data);
            } 
        });
    }
    $(document).ready(function(){
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).on('click','.update',function(){
            
            $('#exampleModal').modal('show');
            var r = $(this).data('row');
            var c = $(this).data('column');
            var i = $(this).data('item');
            var p = $(this).data('price');
            $('#Row1').val(r);
            $('#Column1').val(c);
            $('#ItemName').val(i);
            $('#Price').val(p);
        }); 
        $(document).on('submit','#ProductUpdate',function(e){
            e.preventDefault();
                var url = '{{ route("custom.update", ":id") }}';
                var urlString = url.replace(':id', $('#Row1').val());
                $.ajax({
                    url: urlString,
                    type: "POST",
                    data: $('#ProductUpdate').serialize(),
                    dataType: "json",
                    success: function (data) {                        
                        $('#exampleModal').modal('hide');   
                        getData();
                    }
                });
        });     
    });
    function isNumberKey(evt, obj) {

            var charCode = (evt.which) ? evt.which : event.keyCode
            var value = obj.value;
            var dotcontains = value.indexOf(".") != -1;
            if (dotcontains)
                if (charCode == 46) return false;
            if (charCode == 46) return true;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
    }
</script>
</body>
</html>