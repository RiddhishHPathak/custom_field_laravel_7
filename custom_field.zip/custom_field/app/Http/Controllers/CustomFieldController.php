<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use DB;

class CustomFieldController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {        
        $check = array('id'=>0);
        return view('home',compact('check'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       // dd($request->all());
        $request->validate([
            'Row' => 'required|integer|min:1|digits_between: 1,100',
            'Column' => 'required|integer|min:1|digits_between: 1,100'
        ]);

        $option_table_name = 'field_map';
        $check_table_Fieldspecs = Schema::hasTable($option_table_name);
        if ($check_table_Fieldspecs == "1") {
            $res1 = DB::table('field_map')->where('id',1)->first();
                       
            if($res1->row_count==$request->Row && $res1->column_count==$request->Column ){
                
                $check = array('id'=>1);
                return view('home',compact('check'));

            }else{
            Schema::dropIfExists($option_table_name);
            Schema::create($option_table_name, function ($table) use ($option_table_name) {

                    $table->id();
                    $table->bigInteger('row_count')->default(0);
                    $table->bigInteger('column_count')->default(0);
                    $table->timestamps();
                    $table->charset = 'utf8';
                    $table->collation = 'utf8_unicode_ci';
                });

            $finalData = array(
                'row_count' => $request->Row,
                'column_count' => $request->Column,
                'created_at' => date('Y-m-d H:i:s')
            );
            DB::table($option_table_name)->insert($finalData);
            
            
            $main_table = 'main_table';
            Schema::dropIfExists($main_table);
            Schema::create($main_table, function ($table) use ($main_table) {
                    $table->id();              
                    
            });
            $col = '';                                   
            Schema::table($main_table, function (Blueprint $table) {
                $res = DB::table('field_map')->where('id',1)->first();
                $column_count= $res->column_count;
                for ($i = 1; $i <=$column_count ; $i++) {
                    $col = 'field_'.$i;
                    $table->string($col)->nullable();
                }                
                $table->charset = 'utf8';
                $table->collation = 'utf8_unicode_ci';
            });
            $res = DB::table('field_map')->where('id',1)->first();
            $row_count= $res->row_count;
            $column_count= $res->column_count;
            
            for ($i = 1; $i <=$row_count ; $i++) {
                for ($j = 1; $j <=$column_count ; $j++) {
                    $col = 'field_'.$j;
                    $finalData = array(
                      $col => NULL
                    );
                    
                }
                DB::table($main_table)->insert($finalData);
            }
            $check = array('id'=>1);
            return view('home',compact('check'));

        }
        }else{

        Schema::dropIfExists($option_table_name);
        Schema::create($option_table_name, function ($table) use ($option_table_name) {

                    $table->id();
                    $table->bigInteger('row_count')->default(0);
                    $table->bigInteger('column_count')->default(0);
                    $table->timestamps();
                    $table->charset = 'utf8';
                    $table->collation = 'utf8_unicode_ci';
                });

            $finalData = array(
                'row_count' => $request->Row,
                'column_count' => $request->Column,
                'created_at' => date('Y-m-d H:i:s')
            );
            DB::table($option_table_name)->insert($finalData);
            
            
            $main_table = 'main_table';
            Schema::dropIfExists($main_table);
            Schema::create($main_table, function ($table) use ($main_table) {
                    $table->id();              
                    
            });
            $col = '';                                   
            Schema::table($main_table, function (Blueprint $table) {
                $res = DB::table('field_map')->where('id',1)->first();
                $column_count= $res->column_count;
                for ($i = 1; $i <=$column_count ; $i++) {
                    $col = 'field_'.$i;
                    $table->string($col)->nullable();
                }                
                $table->charset = 'utf8';
                $table->collation = 'utf8_unicode_ci';
            });
            $res = DB::table('field_map')->where('id',1)->first();
            $row_count= $res->row_count;
            $column_count= $res->column_count;
            
            for ($i = 1; $i <=$row_count ; $i++) {
                for ($j = 1; $j <=$column_count ; $j++) {
                    $col = 'field_'.$j;
                    $finalData = array(
                      $col => NULL
                    );
                    
                }
                DB::table($main_table)->insert($finalData);
            }
            $check = array('id'=>1);
            return view('home',compact('check'));    
        }
        
        
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $finalData = array(
            $request->Column => $request->ItemName.'-'.$request->Price     
        );

        DB::table('main_table')->where('id', $id)->update($finalData);
        return response()->json(['status' => 'success']);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function showAll(){
        
        $html = '';
        $html .= '<table>';
        $res = DB::table('field_map')->where('id',1)->first();
        $row_count= $res->row_count;
        $column_count= $res->column_count;
        
        for ($i = 1; $i <=$row_count ; $i++) {
            
            $html .= '<tr>';
            for ($j = 1; $j <=$column_count ; $j++) {
                $col = 'field_'.$j;
                $res = DB::table('main_table')->select($col)->where('id',$i)->first();
                $check_col=$res->$col;
                if($check_col && $check_col!=''){
                    $arr = explode('-', $check_col);
                    $html .= '<td><button type="button" class="btn btn-success update" data-row="'.$i.'" data-column="'.$col.'" data-item="'.$arr[0].'" data-price="'.$arr[1].'">'.$arr[0].'</butto></td>';
                }else{
                    $html .= '<td><button type="button" class="btn btn-success update" data-row="'.$i.'" data-column="'.$col.'">+</butto></td>';
                }
                
            }
            $html .= '</tr>';
        }
        
        
        $html .= '</table>';

        return $html;

    }


}
